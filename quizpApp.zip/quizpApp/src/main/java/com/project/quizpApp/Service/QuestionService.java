package com.project.quizpApp.Service;

import com.project.quizpApp.Entity.Question;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface QuestionService {

    public ResponseEntity<List<Question>> getAllQuestions();


    public ResponseEntity<List<Question>> getAllQuestionsByCategory(String category);

    public ResponseEntity<String> addQuestion(Question question);
}
