package com.project.quizpApp.ServiceImpl;

import com.project.quizpApp.DAO.QuestionDAO;
import com.project.quizpApp.Entity.Question;
import com.project.quizpApp.Service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class QuestionServiceImpl implements QuestionService {

    @Autowired
    QuestionDAO questionDAO;

    @Override
        public ResponseEntity<List<Question>>  getAllQuestions() {
            try{
                return new ResponseEntity<>(questionDAO.findAll(), HttpStatus.OK);
            }catch (Exception ex){
                ex.printStackTrace();
            }
                return new ResponseEntity<>(new ArrayList<>(), HttpStatus.BAD_REQUEST);
        }

    @Override
    public ResponseEntity<List<Question>> getAllQuestionsByCategory(String category) {
//        System.out.println("Service: "+questionDAO.findByCategory(category));
        try{
            return new ResponseEntity<>( questionDAO.findByCategory(category), HttpStatus.OK);
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(), HttpStatus.BAD_REQUEST);
    }

    @Override
    public ResponseEntity<String> addQuestion(Question question) {
        questionDAO.save(question);
        return new ResponseEntity<>("success", HttpStatus.CREATED);
    }
}
