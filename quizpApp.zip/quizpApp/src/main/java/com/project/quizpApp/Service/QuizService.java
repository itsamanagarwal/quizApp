package com.project.quizpApp.Service;


import com.project.quizpApp.Entity.Question;
import com.project.quizpApp.Entity.QuestionWrapper;
import com.project.quizpApp.Entity.Response;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface QuizService {


    public ResponseEntity<String> createQuiz(String category, int numQ, String title);

    public  ResponseEntity<List<QuestionWrapper>> getQuizQuestions(Integer id);

    public ResponseEntity<Integer> calculateResult(Integer id, List<Response> responses);
}
