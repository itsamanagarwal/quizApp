package com.project.quizpApp.Controller;

import com.project.quizpApp.Entity.Question;
import com.project.quizpApp.Service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("question")
public class QuestionController {

    @Autowired
    QuestionService questionService;

    @GetMapping("allQuestions")
    public ResponseEntity<List<Question>> getAllQuestions(){

        return questionService.getAllQuestions();
    }

    @GetMapping("categories/{category}")
    public ResponseEntity<List<Question>> getQuestionByCategory(@PathVariable String category){
//        System.out.println("Controller: "+questionService.getAllQuestionsByCategory(category));
        return questionService.getAllQuestionsByCategory(category);
    }

    @PostMapping("add")
    public ResponseEntity<String> addQuestion(@RequestBody Question question){
        return questionService.addQuestion(question);
    }
}
