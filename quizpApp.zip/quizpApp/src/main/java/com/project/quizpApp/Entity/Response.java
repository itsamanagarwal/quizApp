package com.project.quizpApp.Entity;

import jakarta.persistence.Id;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;

@Data
@RequiredArgsConstructor
public class Response {

    @Id
    Integer id;
    String response;
}

