package com.project.quizpApp.ServiceImpl;


import com.project.quizpApp.DAO.QuestionDAO;
import com.project.quizpApp.DAO.QuizDao;
import com.project.quizpApp.Entity.Question;
import com.project.quizpApp.Entity.QuestionWrapper;
import com.project.quizpApp.Entity.Quiz;
import com.project.quizpApp.Entity.Response;
import com.project.quizpApp.Service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class QuizServiceImpl implements QuizService {

    @Autowired
    QuizDao quizDao;

    @Autowired
    QuestionDAO questionDAO;

    @Override
    public ResponseEntity<String> createQuiz(String category, int numQ, String title) {
        List<Question> questions = questionDAO.findRandomQuestionByCategory( numQ,  category);

        Quiz quiz = new Quiz();
        quiz.setTitle(title);
        quiz.setQuestions((questions));
        quizDao.save(quiz);

        return new ResponseEntity<>("Success", HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<List<QuestionWrapper>> getQuizQuestions(Integer id) {
        Optional<Quiz> quiz = quizDao.findById(id);
//        System.out.println("Quiz join query: " + quiz);
        List<Question> questionsFromDb = quiz.get().getQuestions();
//        System.out.println("questionsFromDb: " + questionsFromDb);
        List<QuestionWrapper> questionForUser = new ArrayList<>();
        for(Question q: questionsFromDb){
            QuestionWrapper qw = new QuestionWrapper(q.getId(), q.getQuestionTitle(), q.getOption1(), q.getOption2(), q.getOption3(), q.getOption4() );
                questionForUser.add(qw);
        }
//        System.out.println("questionForUser: " + questionForUser);
        return new ResponseEntity<>(questionForUser,HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Integer> calculateResult(Integer id, List<Response> responses) {

       Optional<Quiz> quiz = quizDao.findById(id);
//        System.out.println("quiz: " +quiz);
       List<Question> questions = quiz.get().getQuestions();
//        System.out.println("questions: " +questions);
       int right = 0;
       int i = 0;
       for(Response response: responses){
//           System.out.println("response: " +response);
           if(response.getResponse().equals(questions.get(i).getRightAnswer()))
                right++;
           i++;
       }

        return new ResponseEntity<>(right,HttpStatus.OK);
    }


}
