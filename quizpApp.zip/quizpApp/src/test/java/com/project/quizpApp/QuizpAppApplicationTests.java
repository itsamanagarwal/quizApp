package com.project.quizpApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizpAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
